﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

using Mk.DBConnector;
using CommonTypes;

namespace DataAccess
{
    public static class Connection
    {

        internal static DBAdapter Adapter;
        static Connection()
        {

            Connection.Adapter = new DBAdapter(DatabaseType.MySql, Instance.NewInstance, "localhost", 3306, "kfzka", "ukfz", "ukfz", "logdatei.log");

            Connection.Adapter.Adapter.LogFile = true;
        }

        //TODO: Liefert die Liste der KFZ's aus der Datenbank
        public static List<KFZ> GetKfzList()
        {
            List<KFZ> KFZListe = new List<KFZ>();

            string sql = "SELECT * FROM kfz;";

            DataTable t = Connection.Adapter.Adapter.GetDataTable(sql);

            foreach (DataRow r in t.Rows)
            {
                KFZListe.Add(new DA_KFZ(r));
            }

            return KFZListe;
        }

        //TODO: Einfügen eines KFZ in die Datenbank
        public static void InsertKFZ(KFZ kfz)
        {
            
        }

        //TODO: Ändern eines KFZ in der Datenbank
        public static void UpdateKFZ(KFZ kfz)
        {
            
        }

        //TODO: Löschen eines KFZ in der Datenbank
        public static void DeleteKFZ(KFZ kfz)
        {
            
        }
    }
}
