﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using CommonTypes;
using BusinessLogic.Models;

namespace WpfApplication1
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ViewModels.KFZViewModel k = new ViewModels.KFZViewModel();

            k.FahrgestNr = "KJAHDS87687678";
            k.Kennzeichen = "S-PR-9876";
            k.Leistung = 85;
            k.Typ = "SUV";

            //mvm.Insert(k);
        }
    }
}
