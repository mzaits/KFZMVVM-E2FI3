﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using CommonTypes;
using BusinessLogic.Models;


namespace WpfApplication1.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void notifyPropertyChanged(string propname)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propname));
        }        

        private KFZCollectionModel kfzm;
        public ObservableCollection <KFZViewModel> KFZObservableCollection { get; private set; } = new ObservableCollection<KFZViewModel>();

        public MainViewModel()
        {

            kfzm = new KFZCollectionModel();

            foreach (KFZ kfz in kfzm.KFZListe)
            {
                KFZViewModel kfzvm = new KFZViewModel(kfz);
                this.KFZObservableCollection.Add(kfzvm);
            }
        }


    }

    
}
