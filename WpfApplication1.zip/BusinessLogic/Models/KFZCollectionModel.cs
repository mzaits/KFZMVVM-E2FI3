﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel;

using CommonTypes;
using DataAccess;

namespace BusinessLogic.Models
{
    public class KFZCollectionModel
    {
        public List<KFZ> KFZListe = new List<KFZ>();        

        
        public KFZCollectionModel()
        {
            //Alle KFZ aus der Datenquelle abholen und in der Liste speichern:

            this.KFZListe = Connection.GetKfzList();
        }

        public void Insert(KFZ kfz)
        {
            Connection.InsertKFZ(kfz);
        }

        public void Update(KFZ kfz)
        {
            Connection.UpdateKFZ(kfz);
        }

        public void Delete(KFZ kfz)
        {
            Connection.DeleteKFZ(kfz);
        }

        #region Private methods

        

        
        #endregion

    }
}
